﻿using ConsoleApp1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Espaco
{
    public string _nomeEspaco;
    public int _capacidadeMaxima;
    public bool _disponibilidade;
    public double _valorEspaco;

    public Espaco(string nomeEspaco, int capacidade)
    {
        _nomeEspaco = nomeEspaco;
        _capacidadeMaxima = (int)capacidade;
    }
}