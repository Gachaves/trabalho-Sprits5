﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Produto
{
    public string _nome;
    public double _preco;
    public TipoProduto _tipo;
}

public enum TipoProduto
{
    
}