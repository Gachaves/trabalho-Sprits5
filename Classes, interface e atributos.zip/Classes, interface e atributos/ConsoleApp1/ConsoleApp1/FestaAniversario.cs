﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class FestaAniversario : ICategoriaEvento
{
    public double PrecoMesa;
    public double PrecoDecoracao;
    public double PrecoBolo;
    public double PrecoMusica;

    public void DefinirCategoriaEvento(CategoriaEvento categoriaEvento)
    {
        
    }
}
