﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Formatura : ICategoriaEvento
{
    public double PrecoMesa;
    public double PrecoDecoracao;
    public double PrecoMusica;

    public void DefinirCategoriaEvento(CategoriaEvento categoriaEvento)
    {
       
    }
}